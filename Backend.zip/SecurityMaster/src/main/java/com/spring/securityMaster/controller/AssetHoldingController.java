package com.spring.securityMaster.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.securityMaster.dto.AllocationDto;
import com.spring.securityMaster.dto.AssetHoldingsDto;
import com.spring.securityMaster.dto.AssetholdingsResponseDto;
import com.spring.securityMaster.model.Asset;
import com.spring.securityMaster.model.AssetHoldings;
import com.spring.securityMaster.model.Theme;
import com.spring.securityMaster.repository.AssetHoldingsRepository;
import com.spring.securityMaster.repository.AssetRepository;
import com.spring.securityMaster.repository.ThemeRepository;

@RestController
@RequestMapping("/master")
@CrossOrigin(origins = {"http://localhost:2890"})
public class AssetHoldingController {

	@Autowired
	private AssetHoldingsRepository assetHoldingsRepository;
	
	@Autowired
	private AssetRepository assetRepository;
	
	@Autowired
	private ThemeRepository themeRepository;
	
	@PostMapping("/assetHoldings/details")
	public AssetHoldings postAssetHoldings(@RequestBody AssetholdingsResponseDto assetholdingsResponseDto) {
		Theme theme1 = new Theme();
		Asset asset = assetRepository.findById(assetholdingsResponseDto.getAssetId())
				.orElse(null);
		Theme theme = themeRepository.findById(assetholdingsResponseDto.getThemeName())
				.orElse(null);
		if(theme == null) {
			theme = new Theme();
			theme.setThemeName(assetholdingsResponseDto.getThemeName());
			themeRepository.save(theme);
		}
		System.out.println("error");
		AssetHoldings assetHoldings = new AssetHoldings();
		
		assetHoldings.setAsset(asset);
		assetHoldings.setTheme(theme);
		
		Double totalAllocationPercentage = assetHoldingsRepository.getTotalAllocationPercentageByThemeName(assetholdingsResponseDto.getThemeName());
		if(totalAllocationPercentage == null) {
			totalAllocationPercentage = 0.0;
		}
		if( totalAllocationPercentage + assetholdingsResponseDto.getAllocation() > 100.0) {
			throw new RuntimeException("Allocation percentage exceeds 100%");
		}
		assetHoldings.setAllocation(assetholdingsResponseDto.getAllocation());
		
		return assetHoldingsRepository.save(assetHoldings);
	}
	
	@GetMapping("/assetHoldings/{themeName}")
	public List<AssetHoldingsDto> getAssetByThemeName(@PathVariable("themeName") String themeName) {
		List<AssetHoldings> list = assetHoldingsRepository.findByThemeName(themeName);
		List<AssetHoldingsDto> listDto = new ArrayList<>();
		for(AssetHoldings assetHoldings: list) {
			AssetHoldingsDto dto = new AssetHoldingsDto();
			dto.setId(assetHoldings.getAsset().getId());
			dto.setAssetClass(assetHoldings.getAsset().getAssetClass());
			dto.setAssetSubClass(assetHoldings.getAsset().getAssetSubClass());
			dto.setRisk(assetHoldings.getAsset().getRisk());
			dto.setInvestmentHorizon(assetHoldings.getAsset().getInvestmentHorizon());
			dto.setLiquidity(assetHoldings.getAsset().getLiquidity());
			dto.setReturns(assetHoldings.getAsset().getReturns());
			dto.setAllocation(assetHoldings.getAllocation());
			listDto.add(dto);
		}
		return listDto;
	}
	
	@GetMapping("/allcation/{assetId}/{themeName}")
	public AllocationDto getAllocationByassetIdAndThemeName(@PathVariable("themeName") String themeName,
			@PathVariable("assetId") String assetId) {
		AssetHoldings a = assetHoldingsRepository.findByAssetIdAndThemeName(assetId, themeName);
		AllocationDto dto = new AllocationDto();
		dto.setAllocation(a.getAllocation());
		
		
		return dto;
		
		
	}
}
