package com.spring.securityMaster.dto;

public class CompositionDto {

	private double allocation;
	private Double price;
	private Double quantity;
	private String transactinDate;
	private Double valueOfSecurity;
	private String portfolioName;
	private String symbol;
	private String assetId;
	private String transactionType;
	private Double actualAllocation;
	
	
	
	
	public Double getActualAllocation() {
		return actualAllocation;
	}
	public void setActualAllocation(Double actualAllocation) {
		this.actualAllocation = actualAllocation;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	public double getAllocation() {
		return allocation;
	}
	public void setAllocation(double allocation) {
		this.allocation = allocation;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public String getTransactinDate() {
		return transactinDate;
	}
	public void setTransactinDate(String transactinDate) {
		this.transactinDate = transactinDate;
	}
	public Double getValueOfSecurity() {
		return valueOfSecurity;
	}
	public void setValueOfSecurity(Double valueOfSecurity) {
		this.valueOfSecurity = valueOfSecurity;
	}
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	
	
}
