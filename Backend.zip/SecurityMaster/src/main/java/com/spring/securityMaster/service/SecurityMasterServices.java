package com.spring.securityMaster.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.persistence.EntityNotFoundException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.securityMaster.enums.AssetClassRisk;
import com.spring.securityMaster.model.Asset;
import com.spring.securityMaster.model.Industry;
import com.spring.securityMaster.model.IndustryGroup;
import com.spring.securityMaster.model.Price;
import com.spring.securityMaster.model.Sectors;
import com.spring.securityMaster.model.Security;
import com.spring.securityMaster.model.SubIndustry;
import com.spring.securityMaster.model.Theme;
import com.spring.securityMaster.repository.AssetRepository;
import com.spring.securityMaster.repository.IndustryGroupRepository;
import com.spring.securityMaster.repository.IndustryRepository;
import com.spring.securityMaster.repository.PriceRepository;
import com.spring.securityMaster.repository.SectorRepository;
import com.spring.securityMaster.repository.SecurityRepository;
import com.spring.securityMaster.repository.SubIndustryRepository;
import com.spring.securityMaster.repository.ThemeRepository;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

@Service
public class SecurityMasterServices {
	private static final AssetClassRisk AssetClassRisk = null;

	@Autowired
	private SecurityRepository securityRepository;
	
	@Autowired
	private PriceRepository priceRepository;
	
	@Autowired
	private AssetRepository assetRepository;
	
	@Autowired
	private ThemeRepository themeRepository;
	
	@Autowired
	private SectorRepository sectorRepository;
	
	@Autowired
	private IndustryGroupRepository industryGroupRepository;
	
	@Autowired
	private IndustryRepository industryRepository;
	
	@Autowired
	private SubIndustryRepository subIndustryRepository; 
	
	String line="";
	String newLine = "";

	public String saveData() {
	try(BufferedReader br=new BufferedReader(new FileReader("src/main/resources/files/final csv file 2.csv")))
	{
//		boolean rowFound = false;
	while((line=br.readLine())!=null) {
	String [] data=line.split(",");
//	String [] data1=line1.split(",");
	
	Security m=new Security();
//	Asset m2 = new Asset();
	
	m.setSymbol(data[1]);
	m.setDescription(data[2]);
	m.setSector(data[3]);
	m.setIndustry(data[4]);
	m.setExchange(data[5]);
	m.setIsinNumber(data[7]);
	m.setCurrency(data[6]);
	m.setPreviousPrice(data[8]);
	
	m.setLastPrice(fetchCurrentPrice(data[1]));
	
	m.setTimeStamp(data[9]);
	m.setEquityCategory(data[10]);
	
	String assetName = data[11];
	
	Asset asset = assetRepository.findById(assetName).orElse(null);
	if(asset == null) {
		asset = new Asset();
		asset.setAssetClass(assetName);
		assetRepository.save(asset);
	}
	m.setAsset(asset);
	
	String subIndustryId = data[12];
	
	SubIndustry subIndustry = subIndustryRepository.findById(subIndustryId).orElse(null);
	
	if(subIndustry == null) {
	subIndustry=new SubIndustry();
	subIndustry.setId(subIndustryId);
	subIndustryRepository.save(subIndustry);
	}
	m.setSubIndustry(subIndustry);

//	String id = data[12];
//	Long assetId = Long.parseLong(id);
//	Asset asset = assetRepository.findById(assetId).orElseThrow(() -> new EntityNotFoundException("Asset not found with ID: " + assetId));
//	m.setAsset(asset);
//	if (data[0].equals(data1[1])) {
//		m.setLastPrice(data1[2]);
//		m.setTimeStamp(data1[3]);
//		rowFound = true;
//		break;
//	}
	
	securityRepository.save(m);
	}
	}
	
	catch(IOException e) {
	e.printStackTrace();
	}
	return line;
	}
	
	String line1="";
	
	public String saveData1() {
		try(BufferedReader br=new BufferedReader(new FileReader("src/main/resources/files/price1.csv")))
		{
			while((line1=br.readLine())!=null) {
				String [] data=line1.split(",");
				Price m1=new Price();
				Security m=new Security();

				m.setSymbol(data[1]);
//				m.setSymbol(data[0]);
				m1.setId(data[0]);
				m1.setSecurity(m);
				m1.setLastPrice(data[2]);
				m1.setDate(data[3]);
				priceRepository.save(m1);
		}
			
	}
		
		catch(IOException e) {
			e.printStackTrace();
			}
		return line1;
	}
	public String saveData3() {
		try(BufferedReader br3=new BufferedReader(new FileReader("src/main/resources/files/Asset.csv"))){
			while((line1=br3.readLine())!=null) {
				String [] data3=line1.split(",");
				Asset m4 = new Asset();
//				Theme theme = new Theme();
				
				m4.setId(data3[0]);
				m4.setAssetClass(data3[1]);
				m4.setAssetSubClass(data3[2]);
				m4.setRisk(data3[3]);
				m4.setInvestmentHorizon(data3[4]);
				m4.setReturns(data3[5]);
				m4.setLiquidity(data3[6]);
//				String themeName = data3[7];
//				Theme theme = themeRepository.findById(themeName).orElse(null);
//				
//				if(theme == null) {
//					theme = new Theme();
//					theme.setThemeName(themeName);
//					themeRepository.save(theme);
//				}
//				m4.setTheme(theme);
				
//				String assetName = data[12];
//				
//				Asset asset = assetRepository.findById(assetName).orElse(null);
//				if(asset == null) {
//					asset = new Asset();
//					asset.setAssetClass(assetName);
//					assetRepository.save(asset);
//				}
//				m.setAsset(asset);
//				if(asset == null) {
//					asset = new Asset();
//					asset.setAssetClass(assetName);
//					assetRepository.save(asset);
//				}
//				m.setAsset(asset);
				assetRepository.save(m4);
			}
		}
		catch(IOException e) {
			e.printStackTrace();
			}
		return line;
		
	}
	public String saveData2() {
		String newLine = null ;
//		String oldLine;
		try {
			BufferedReader newFileReader = new BufferedReader(new FileReader("src/main/resources/files/price1.csv"));
			BufferedWriter oldFileWriter = new BufferedWriter(new FileWriter("src/main/resources/files/final csv file.csv"));

			Price m1=new Price();
			
			Security m=new Security();

//			String newLine;
			while ((newLine = newFileReader.readLine()) != null) {
			String[] newValues = newLine.split(",");
			boolean rowFound = false;
			String oldLine;
			while ((oldLine = newFileReader.readLine()) != null) {
			String[] oldValues = oldLine.split(",");
			if (oldValues[0].equals(newValues[1])) {
			m.setLastPrice(newValues[2]);
			m.setTimeStamp(newValues[3]);
			oldLine = newLine;
			rowFound = true;
			break;
			}
			}
			if (!rowFound) {
			oldFileWriter.write(newLine);
			oldFileWriter.newLine();
			} else {
			oldFileWriter.write(oldLine);
			oldFileWriter.newLine();
			}
			}

			newFileReader.close();
			oldFileWriter.close();
			} catch (IOException e) {
			e.printStackTrace();
			}
		return newLine;
	}
	
	String line2 = "";

	public String saveData4() {
		try (BufferedReader br4 = new BufferedReader(new FileReader("src/main/resources/files/Sectors.csv"))) {
			while ((line2 = br4.readLine()) != null) {
				String[] data4 = line2.split(",");
				Sectors m5 = new Sectors();

				m5.setId(data4[0]);
				m5.setSectorName(data4[1]);
				sectorRepository.save(m5);

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return line2;
	}

	String line3 = "";

	public String saveData5() {
		try (BufferedReader br5 = new BufferedReader(new FileReader("src/main/resources/files/IndustryGroup.csv"))) {
			while ((line3 = br5.readLine()) != null) {
				String[] data5 = line3.split(",");
				IndustryGroup m6 = new IndustryGroup();

				m6.setId(data5[0]);
				m6.setIndustryGroupName(data5[1]);
				// m6.setctor(data5[2]

				// m6.setSectorId(data5[2]);

				industryGroupRepository.save(m6);

			}

		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return line3;
	}

	String line4 = "";

	public String saveData6() {
		try (BufferedReader br6 = new BufferedReader(new FileReader("src/main/resources/files/Industry.csv"))) {
			while ((line4 = br6.readLine()) != null) {
				String[] data6 = line4.split(",");
				Industry m7 = new Industry();

				m7.setId(data6[0]);
				m7.setIndustryName(data6[1]);
				// m7.setIndustryGroupId(data6[2]);
				industryRepository.save(m7);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return line4;
	}

	String line5 = "";

	public String saveData7() {
		try (BufferedReader br7 = new BufferedReader(new FileReader("src/main/resources/files/SubIndustries.csv"))) {
			while ((line5 = br7.readLine()) != null) {
				String[] data7 = line5.split(",");
				SubIndustry m8 = new SubIndustry();
				m8.setId(data7[0]);
				m8.setSubIndustryName(data7[1]);
				String industryId = data7[2];

				Industry industry = industryRepository.findById(industryId).orElse(null);

				if (industry == null) {
					industry = new Industry();
					industry.setId(industryId);
					industryRepository.save(industry);
				}

				m8.setIndustry(industry);

				String industryGroupId = data7[3];
				IndustryGroup industryGroup = industryGroupRepository.findById(industryGroupId).orElse(null);

				if (industryGroup == null) {
					industryGroup = new IndustryGroup();
					industryGroup.setId(industryGroupId);
					industryGroupRepository.save(industryGroup);
				}

				m8.setIndustryGroup(industryGroup);
				String sectorId = data7[4];
				Sectors sectors = sectorRepository.findById(sectorId).orElse(null);

				if (sectors == null) {
					sectors = new Sectors();
					sectors.setId(sectorId);
					sectorRepository.save(sectors);
				}
				m8.setSectors(sectors);
				subIndustryRepository.save(m8);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return line5;

	}
	
	private String fetchCurrentPrice(String symbol) {
		String url = "https://markets.ft.com/data/equities/tearsheet/summary?s="+ symbol;
		try {
			Document document = Jsoup.connect(url).get();
			Elements elements = document.select("span[class=mod-ui-data-list__value]");
			String priceString = elements.get(0).text();
			return priceString;
//			HttpClient httpClient = HttpClientBuilder.create().build();
//			System.out.println(httpClient);
//			System.out.println("1111");
//			HttpGet request = new HttpGet(apiUrl);
//			System.out.println("2222");
//			System.out.println(request);
//			HttpResponse response = httpClient.execute(request);
//			System.out.println("3333");
//			System.out.println(response);
//			HttpEntity entity = response.getEntity();
//			System.out.println("4444");
//			System.out.println(entity);
//			String jsonResult = EntityUtils.toString(entity);
//			System.out.println("5555");
//			System.out.println(jsonResult);
//			
//			String currentPrice = jsonResult.substring( jsonResult.indexOf(":") + 1, jsonResult.indexOf("}"));
//			System.out.println(currentPrice);
//			return currentPrice;
		}catch (IOException e) {
			e.printStackTrace();
		}
		return symbol;
		
		
	}
}









































//public String loader() {
//String str = null;
//StringBuilder strb = new StringBuilder();
//String filePath = "src/main/resources/final csv file.csv";
//
//try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
//    while ((str = br.readLine()) != null) {
//        strb.append(str).append("\n");
//    }
//} catch (FileNotFoundException f) {
//  
//    @SuppressWarnings("unused")
//	final Logger logger = Logger.getLogger(filePath + " does not exist");
//    return null;
//} catch (IOException e) {
//    e.printStackTrace();
//}
//
//return strb.toString();
//}
//public void saveUnifiedMaster() throws IOException {
// String line = "";
// try {
// BufferedReader br = new BufferedReader(new FileReader("src/main/resources/Book4 (1).csv"));
// while ((line = br.readLine()) != null) {
// String[] data = line.split(",");
// Security s = new Security();
// s.setId(data[0]);
// s.setSymbol(data[1]);
// s.setDescription(data[2]);
// s.setSector(data[3]);
// s.setIndustry(data[4]);
// s.setExchange(data[5]);
// s.setIsinNumber(data[6]);
// s.setCurrency(data[7]);
// securityRepository.save(s);
// }
// } catch (FileNotFoundException e) {
// e.printStackTrace();
// }
//}
