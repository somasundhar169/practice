package com.spring.securityMaster.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.securityMaster.model.SubIndustry;
import com.spring.securityMaster.repository.SubIndustryRepository;

@RestController
@RequestMapping("/master")
@CrossOrigin(origins = {"http://localhost:2890"})
public class TreeGridController {

	@Autowired

	private SubIndustryRepository subIndustryRepository;

	 

	@GetMapping("/getall/subindustry111")

	public List<SubIndustry> getAllSubIndustry() {

	return subIndustryRepository.findAll();

	 

	}
}
