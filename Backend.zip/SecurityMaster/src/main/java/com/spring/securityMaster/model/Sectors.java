package com.spring.securityMaster.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Sectors {

	@Id
	private String id;

	private String sectorName;

	public Sectors() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sectors(String id, String sectorName) {
		super();
		this.id = id;
		this.sectorName = sectorName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	@Override
	public String toString() {
		return "Sectors [id=" + id + ", sectorName=" + sectorName + "]";
	}
	
	
}
