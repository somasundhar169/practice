package com.spring.securityMaster.controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.securityMaster.dto.ErrorResponse;
import com.spring.securityMaster.dto.PortfolioDto;
import com.spring.securityMaster.model.Portfolio;
import com.spring.securityMaster.model.Theme;
import com.spring.securityMaster.repository.PortfolioRepository;
import com.spring.securityMaster.repository.ThemeRepository;

@RestController
@RequestMapping("/master")
@CrossOrigin(origins = {"http://localhost:2890"})
public class PortfolioHeaderController {

	@Autowired
	private PortfolioRepository portfolioRepository;
	
	@Autowired
	private ThemeRepository themeRepository;
	
	@PostMapping("/post/portfolio")
	public ResponseEntity<?> insertPortfolio(@RequestBody PortfolioDto portfolioDto) {
		
		Optional<Theme> optional = themeRepository.findById(portfolioDto.getThemeName());
		if(!optional.isPresent())
			throw new RuntimeException("theme is invalid");
		
		Theme theme = optional.get();
		Portfolio portfolio = new Portfolio();

		
		portfolio.setPortfolioName(portfolioDto.getPortfolioName());
		System.out.println("233");
				
		System.out.println("theme");
		portfolio.setCurrency(portfolioDto.getCurrency());
		
		portfolio.setExchange(portfolioDto.getExchange());
		
		portfolio.setTheme(theme);
		
		portfolio.setRebalancingFrequency(portfolioDto.getRebalancingFrequency());
		portfolio.setInvestmentValue(portfolioDto.getInvestmentValue());
		portfolio.setRemainingBalance(portfolioDto.getInvestmentValue());
		portfolio.setCurrentValue(0.0);
		portfolio.setRemainingAllocation(100); 
		portfolio.setInvestedAmount(0.0);
		portfolio.setBenchmark("IISL Nifty 100 PR INR");
		portfolio.setNetEarnings(0.0);
		portfolio.setpAndLStatement("New");
		portfolio.setStatus("Active");
		
		portfolioRepository.save(portfolio);
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setMessage("Portfolio Inserted...");
		
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	@GetMapping("/portfolio/{portfolioName}")
	public PortfolioDto getPortfolioByName(@PathVariable("portfolioName") String portfolioName) {
		Portfolio p = portfolioRepository.findbyName(portfolioName);
		PortfolioDto dto = new PortfolioDto();
		dto.setPortfolioName(p.getPortfolioName());
		dto.setThemeName(p.getTheme().getThemeName());
		BigDecimal roundedInvestedAmount = BigDecimal.valueOf(p.getInvestedAmount())
				.setScale(2, RoundingMode.HALF_UP);
		BigDecimal roundedRemainingBalance = BigDecimal.valueOf(p.getRemainingBalance())
				.setScale(2, RoundingMode.HALF_UP);
		BigDecimal roundInvestmentValue = BigDecimal.valueOf(p.getInvestmentValue())
				.setScale(2, RoundingMode.HALF_UP);
		BigDecimal roundCurrentValue = BigDecimal.valueOf(p.getCurrentValue())
				.setScale(2, RoundingMode.HALF_UP);
		dto.setInvestedAmount(roundedInvestedAmount.doubleValue());
		dto.setCurrentValue(roundCurrentValue.doubleValue());
		dto.setCurrency(p.getCurrency());
		dto.setExchange(p.getExchange());
		dto.setInvestmentValue(roundInvestmentValue.doubleValue());
		dto.setRebalancingFrequency(p.getRebalancingFrequency());
		dto.setRemainingBalance(roundedRemainingBalance.doubleValue());
		dto.setRemainingAllocation(p.getRemainingAllocation());
		dto.setBenchmark(p.getBenchmark());
		dto.setStatus(p.getStatus());
		dto.setNetEarnings(p.getNetEarnings());
		dto.setpAndLStatement(p.getpAndLStatement());
		return dto;
	}
	@GetMapping("/all/portfolio")
	public List<PortfolioDto> getAllPortfolio() {
		List<Portfolio> list = portfolioRepository.findAll();
		List<PortfolioDto> listdto = new ArrayList<>();
		for(Portfolio p : list) {
			PortfolioDto dto = new PortfolioDto();
			dto.setPortfolioName(p.getPortfolioName());
			dto.setThemeName(p.getTheme().getThemeName());
			BigDecimal roundedInvestedAmount = BigDecimal.valueOf(p.getInvestedAmount())
					.setScale(2, RoundingMode.HALF_UP);
			BigDecimal roundedRemainingBalance = BigDecimal.valueOf(p.getRemainingBalance())
					.setScale(2, RoundingMode.HALF_UP);
			BigDecimal roundInvestmentValue = BigDecimal.valueOf(p.getInvestmentValue())
					.setScale(2, RoundingMode.HALF_UP);
			BigDecimal roundCurrentValue = BigDecimal.valueOf(p.getCurrentValue())
					.setScale(2, RoundingMode.HALF_UP);
			dto.setInvestedAmount(roundedInvestedAmount.doubleValue());
			dto.setCurrentValue(roundCurrentValue.doubleValue());
			dto.setCurrency(p.getCurrency());
			dto.setExchange(p.getExchange());
			dto.setInvestmentValue(roundInvestmentValue.doubleValue());
			dto.setRebalancingFrequency(p.getRebalancingFrequency());
			dto.setRemainingBalance(roundedRemainingBalance.doubleValue());
			dto.setRemainingAllocation(p.getRemainingAllocation());
			dto.setBenchmark(p.getBenchmark());
			dto.setNetEarnings(p.getNetEarnings());
			dto.setStatus(p.getStatus());
			dto.setpAndLStatement(p.getpAndLStatement());
			listdto.add(dto);
		}
		return listdto;
	}
	@PutMapping("update/{name}")
	public ResponseEntity<String> updateStatus(@PathVariable("name") String portfolioName){
	Optional<Portfolio> optional=portfolioRepository.findbyNameU(portfolioName);
	if(optional.isPresent()) {
	Portfolio portfolio=optional.get();
	portfolio.setStatus("inactive");
	portfolioRepository.save(portfolio);
	return ResponseEntity.ok("Portfolio status uploaded");
	}else {
	return ResponseEntity.notFound().build();
	}
	}

	 
//	public void updatePortfolioCurrentValue(String portfolioName) {
//		Portfolio portfolio = portfolioRepository.findById(portfolioName).orElseThrow(() -> new RuntimeException("Portfolio Not Found"));
//		Double currentValue = portfolio.calculateCurretValue();
//		portfolio.setCurrentValue(currentValue);
//		portfolio.setInvestedAmount(currentValue);
//		
//		portfolioRepository.save(portfolio);
//	}
}
