package com.spring.securityMaster.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.securityMaster.model.Portfolio;
import com.spring.securityMaster.model.Theme;

public interface PortfolioRepository extends JpaRepository<Portfolio, String>{

	@Query("select p from Portfolio p where p.portfolioName=?1")
	Portfolio findbyName(String portfolioName);

	@Query("select p from Portfolio p where p.theme.themeName=?1")
	Theme findByName(String theme);

	@Query("select p from Portfolio p where p.portfolioName=?1")
	Optional<Portfolio> findbyNameU(String portfolioName);

}
