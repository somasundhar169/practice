package com.spring.securityMaster.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.spring.securityMaster.model.AssetHoldings;

public interface AssetHoldingsRepository extends JpaRepository<AssetHoldings, Long>{

	@Query("select a from AssetHoldings a where a.theme.themeName=?1")
	List<AssetHoldings> findByThemeName(String themeName);

	@Query("SELECT SUM(a.allocation) FROM AssetHoldings a WHERE a.theme.themeName=?1")
	Double getTotalAllocationPercentageByThemeName(String themeName);

	@Query("select a from AssetHoldings a where a.asset.id=?1 and a.theme.themeName=?2")
	AssetHoldings findByAssetIdAndThemeName(String assetId, String themeName);

}
