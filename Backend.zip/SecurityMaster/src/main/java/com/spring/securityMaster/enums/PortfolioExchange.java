package com.spring.securityMaster.enums;

public enum PortfolioExchange {
	NSE, BSE
}
