package com.spring.securityMaster.repository;

import java.util.List;
import org.springframework.data.domain.Sort;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.securityMaster.model.Security;

public interface SecurityRepository extends JpaRepository<Security, String>{

	@Query("select s from Security s where s.symbol=?1")
	Optional<Security> findBySymbol(String symbol);

	@Query("select s from Security s where s.isinNumber=?1")
	Optional<Security> findByIsinNumber(String isinNumber);

	@Query("select s from Security s where s.sector LIKE %?1%")
	List<Security> getBySector(String sector, Sort sort);

	@Query("select s from Security s where s.industry LIKE %?1%")
	List<Security> getByIndusty(String industry, Sort sort);

	@Query("select s from Security s where s.symbol=?1")
	Security findBySymbol1(String symbol);

	@Query("select s from Security s where s.asset.id=?1")
	List<Security> findByAssetId(String assetId);

}
