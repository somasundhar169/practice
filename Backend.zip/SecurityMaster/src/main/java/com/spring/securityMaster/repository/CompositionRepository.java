package com.spring.securityMaster.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.securityMaster.model.Asset;
import com.spring.securityMaster.model.Composition;
import com.spring.securityMaster.model.Portfolio;

public interface CompositionRepository extends JpaRepository<Composition, Long>{

	@Query("select c from Composition c where c.portfolio.portfolioName=?1")
	List<Composition> findByPortfolio(Portfolio portfolio);

	@Query("select c from Composition c where c.security.symbol=?1")
	List<Composition> findBySecuritySymbol(String symbol);

	@Query("select c from Composition c where c.portfolio.portfolioName=?1")
	List<Composition> findByPortfolioName(String portfolioName);

	@Query("select c from Composition c where c.portfolio.portfolioName=?1 and c.asset.id=?2 and c.security.symbol=?3")
	Composition findByPortfolioAndAsset(String portfolioName, String assetClass, String symbol);
	
	@Query("select c from Composition c where c.portfolio.portfolioName=?1 and c.asset.id=?2")
	Composition findByPortfolioAndAsset(String portfolioName, String assetClass);
	
	@Query("select c from Composition c where c.portfolio.portfolioName=?1 and c.asset.id=?2")
	List<Composition> findByPortfolioAndAsset1(String portfolioName, String assetClass);

	@Query("select c from Composition c where c.portfolio.portfolioName=?1 and c.asset.id=?2 and c.security.symbol=?3")
	Composition findByPortfolioAndAssetAndSecurity(String portfolioName, String assetClass, String symbol);
	
	@Query("select c from Composition c where c.portfolio.portfolioName=?1 and c.asset.id=?2")
	List<Composition> findByPortfolioAndAsset2(String portfolioName, String assetClass);

	
	

}
