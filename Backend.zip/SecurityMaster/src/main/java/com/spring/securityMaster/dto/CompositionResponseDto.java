package com.spring.securityMaster.dto;

import java.time.LocalDate;

import com.spring.securityMaster.enums.PortfolioExchange;

public class CompositionResponseDto {

	private double allocation;
	private Double price;
	private Double quantity;
	private LocalDate transactinDate;
	private Double valueOfSecurity;
	private String portfolioName;
	private String currency;
	private PortfolioExchange exchange;
	private String benchmark;
	private String symbol;
	private String description;
	private String equityCategory;
	private String assetClass;
	private String assetSubClass;
	private String risk;
	private String investmentHorizon;
//	private String returns;
	private String liquidity;
	private String transactionType;
	private Double actualAllocation;
	
	
	
	public Double getActualAllocation() {
		return actualAllocation;
	}
	public void setActualAllocation(Double actualAllocation) {
		this.actualAllocation = actualAllocation;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getRisk() {
		return risk;
	}
	public void setRisk(String risk) {
		this.risk = risk;
	}
	public String getInvestmentHorizon() {
		return investmentHorizon;
	}
	public void setInvestmentHorizon(String investmentHorizon) {
		this.investmentHorizon = investmentHorizon;
	}
	public String getLiquidity() {
		return liquidity;
	}
	public void setLiquidity(String liquidity) {
		this.liquidity = liquidity;
	}
	public String getAssetSubClass() {
		return assetSubClass;
	}
	public void setAssetSubClass(String assetSubClass) {
		this.assetSubClass = assetSubClass;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public double getAllocation() {
		return allocation;
	}
	public void setAllocation(double allocation) {
		this.allocation = allocation;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public LocalDate getTransactinDate() {
		return transactinDate;
	}
	public void setTransactinDate(LocalDate transactinDate) {
		this.transactinDate = transactinDate;
	}
	public Double getValueOfSecurity() {
		return valueOfSecurity;
	}
	public void setValueOfSecurity(Double valueOfSecurity) {
		this.valueOfSecurity = valueOfSecurity;
	}
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public PortfolioExchange getExchange() {
		return exchange;
	}
	public void setExchange(PortfolioExchange exchange) {
		this.exchange = exchange;
	}
	public String getBenchmark() {
		return benchmark;
	}
	public void setBenchmark(String benchmark) {
		this.benchmark = benchmark;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEquityCategory() {
		return equityCategory;
	}
	public void setEquityCategory(String equityCategory) {
		this.equityCategory = equityCategory;
	}
	
	
}
