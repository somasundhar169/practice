package com.spring.securityMaster.dto;

import javax.persistence.Column;

public class SecurityResponseDto {

	private String symbol;
	private String description;
	private String sector;
	private String industry;
	private String exchange;
	private String isinNumber;
	private String currency;
	private String lastPrice;
	private String previousPrice;
	private String equityCategory;
	private String assetName;
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getPreviousPrice() {
		return previousPrice;
	}
	public void setPreviousPrice(String previousPrice) {
		this.previousPrice = previousPrice;
	}
	public String getEquityCategory() {
		return equityCategory;
	}
	public void setEquityCategory(String equityCategory) {
		this.equityCategory = equityCategory;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getExchange() {
		return exchange;
	}
	public void setExchange(String exchange) {
		this.exchange = exchange;
	}
	public String getIsinNumber() {
		return isinNumber;
	}
	public void setIsinNumber(String isinNumber) {
		this.isinNumber = isinNumber;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getLastPrice() {
		return lastPrice;
	}
	public void setLastPrice(String lastPrice) {
		this.lastPrice = lastPrice;
	}
	@Override
	public String toString() {
		return "SecurityResponseDto [symbol=" + symbol + ", description=" + description + ", sector=" + sector
				+ ", industry=" + industry + ", exchange=" + exchange + ", isinNumber=" + isinNumber + ", currency="
				+ currency + ", lastPrice=" + lastPrice + "]";
	}
	
	
}
