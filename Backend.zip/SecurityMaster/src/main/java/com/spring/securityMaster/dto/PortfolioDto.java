package com.spring.securityMaster.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;

import com.spring.securityMaster.enums.PortfolioCurrency;
import com.spring.securityMaster.enums.PortfolioExchange;
import com.spring.securityMaster.model.Theme;

public class PortfolioDto {

private String portfolioName;
	

	private PortfolioCurrency currency;
	private PortfolioExchange exchange;
	private String benchmark;
	private String themeName;
	private Double remainingBalance;
	private String rebalancingFrequency;
	private Double investmentValue;
	private Double currentValue;
	private double remainingAllocation;
	private Double investedAmount;
	private Double netEarnings;
	private String pAndLStatement;
	private String status;
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	public PortfolioCurrency getCurrency() {
		return currency;
	}
	public void setCurrency(PortfolioCurrency currency) {
		this.currency = currency;
	}
	public PortfolioExchange getExchange() {
		return exchange;
	}
	public void setExchange(PortfolioExchange exchange) {
		this.exchange = exchange;
	}
	public String getBenchmark() {
		return benchmark;
	}
	public void setBenchmark(String benchmark) {
		this.benchmark = benchmark;
	}
	public String getThemeName() {
		return themeName;
	}
	public void setThemeName(String themeName) {
		this.themeName = themeName;
	}
	public Double getRemainingBalance() {
		return remainingBalance;
	}
	public void setRemainingBalance(Double remainingBalance) {
		this.remainingBalance = remainingBalance;
	}
	public String getRebalancingFrequency() {
		return rebalancingFrequency;
	}
	public void setRebalancingFrequency(String rebalancingFrequency) {
		this.rebalancingFrequency = rebalancingFrequency;
	}
	public Double getInvestmentValue() {
		return investmentValue;
	}
	public void setInvestmentValue(Double investmentValue) {
		this.investmentValue = investmentValue;
	}
	public Double getCurrentValue() {
		return currentValue;
	}
	public void setCurrentValue(Double currentValue) {
		this.currentValue = currentValue;
	}
	public double getRemainingAllocation() {
		return remainingAllocation;
	}
	public void setRemainingAllocation(double remainingAllocation) {
		this.remainingAllocation = remainingAllocation;
	}
	public Double getInvestedAmount() {
		return investedAmount;
	}
	public void setInvestedAmount(Double investedAmount) {
		this.investedAmount = investedAmount;
	}
	public Double getNetEarnings() {
		return netEarnings;
	}
	public void setNetEarnings(Double netEarnings) {
		this.netEarnings = netEarnings;
	}
	public String getpAndLStatement() {
		return pAndLStatement;
	}
	public void setpAndLStatement(String pAndLStatement) {
		this.pAndLStatement = pAndLStatement;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
}
