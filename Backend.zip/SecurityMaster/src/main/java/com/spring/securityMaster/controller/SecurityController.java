package com.spring.securityMaster.controller;

import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.securityMaster.dto.SecurityResponseDto;
import com.spring.securityMaster.model.Price;
import com.spring.securityMaster.model.Security;
import com.spring.securityMaster.repository.PriceRepository;
import com.spring.securityMaster.repository.SecurityRepository;
import com.spring.securityMaster.service.CalculationService;
import com.spring.securityMaster.service.SecurityMasterServices;

@RestController
@RequestMapping("/master")
@CrossOrigin(origins = {"http://localhost:2890"})
public class SecurityController {

	@Autowired
	private SecurityRepository securityRepository;
	@Autowired
	private PriceRepository priceRepository;
	
	@Autowired
	SecurityMasterServices service;
	
	@Autowired
	private CalculationService calculationService;
	
	@RequestMapping("/api")
	public String setData() {
		return service.saveData();
	}
	@RequestMapping("/api1")
	public String setData1() {
		return service.saveData1();
	}
	
	@RequestMapping("/api3")
	public String setData3() {
		return service.saveData3();
	}
	
	@RequestMapping("/api4")
	public String setData4() {
	return service.saveData4();
	}
	
	@RequestMapping("/api5")
	public String setData5() {
	return service.saveData5();
	}
	
	@RequestMapping("/api6")
	public String setData6() {
	return service.saveData6();
	}
	
	@RequestMapping("/api7")
	public String setData7() {
	return service.saveData7();
	}
	
	@GetMapping("/stocks/{assetId}")
	public List<SecurityResponseDto> getByAssetId(@PathVariable("assetId") String assetId) {
		List<Security> list = securityRepository.findByAssetId(assetId);
		
		List<SecurityResponseDto> lisDto = new ArrayList<>();
		for(Security s : list) {
			SecurityResponseDto dto = new SecurityResponseDto();
			dto.setSymbol(s.getSymbol());
			dto.setDescription(s.getDescription());
			dto.setSector(s.getSector());
			dto.setIndustry(s.getIndustry());
			dto.setExchange(s.getExchange());
			dto.setIsinNumber(s.getIsinNumber());
			dto.setCurrency(s.getCurrency());
			dto.setLastPrice(s.getLastPrice());
			dto.setPreviousPrice(s.getPreviousPrice());
			dto.setEquityCategory(s.getEquityCategory());
			dto.setAssetName(s.getAsset().getAssetClass());
			lisDto.add(dto);
		}
		return lisDto;
	}
	
	@GetMapping("/all/{symbol}")
	public SecurityResponseDto getBySymbol(@PathVariable("symbol") String symbol) {
		
		Optional<Security> optional = securityRepository.findBySymbol(symbol);
		
		if(!optional.isPresent())
			throw new RuntimeException("symbol is invalid");
		
		SecurityResponseDto dto = new SecurityResponseDto();
		Security s = optional.get();
		dto.setSymbol(s.getSymbol());
		dto.setDescription(s.getDescription());
		dto.setSector(s.getSector());
		dto.setIndustry(s.getIndustry());
		dto.setExchange(s.getExchange());
		dto.setIsinNumber(s.getIsinNumber());
		dto.setCurrency(s.getCurrency());
		dto.setLastPrice(s.getLastPrice());
		dto.setPreviousPrice(s.getPreviousPrice());
		dto.setEquityCategory(s.getEquityCategory());
		dto.setAssetName(s.getAsset().getAssetClass());
		
		return dto;
		
	}
	@GetMapping("/all/isin/{isinNumber}")
	public SecurityResponseDto getByIsin1(@PathVariable("isinNumber") String isinNumber) {
		Optional<Security> optional = securityRepository.findByIsinNumber(isinNumber);
		if(!optional.isPresent())
			throw new RuntimeException("isin is invalid");
		SecurityResponseDto dto = new SecurityResponseDto();
		Security s = optional.get();
		dto.setSymbol(s.getSymbol());
		dto.setDescription(s.getDescription());
		dto.setSector(s.getSector());
		dto.setIndustry(s.getIndustry());
		dto.setExchange(s.getExchange());
		dto.setIsinNumber(s.getIsinNumber());
		dto.setCurrency(s.getCurrency());
		dto.setLastPrice(s.getLastPrice());
		dto.setPreviousPrice(s.getPreviousPrice());
		dto.setEquityCategory(s.getEquityCategory());
		return dto;
	}
	
	
	
	@GetMapping("/isin/{isinNumber}")
	public Security getByIsin(@PathVariable("isinNumber") String isinNumber) {
		Optional<Security> optional = securityRepository.findByIsinNumber(isinNumber);
		if(!optional.isPresent())
			throw new RuntimeException("isinNumber is invalid");
		
		return optional.get();
	}
	
	
	
	@GetMapping("/i/sector/{sector}")
	public List<SecurityResponseDto> getBySector(@PathVariable("sector") String sector,
										 String description){
		List<Security> list = securityRepository.getBySector(sector, Sort.by("description").ascending());
		
		List<SecurityResponseDto> lisDto = new ArrayList<>();
		for(Security s : list) {
			SecurityResponseDto dto = new SecurityResponseDto();
			dto.setSymbol(s.getSymbol());
			dto.setDescription(s.getDescription());
			dto.setSector(s.getSector());
			dto.setIndustry(s.getIndustry());
			dto.setExchange(s.getExchange());
			dto.setIsinNumber(s.getIsinNumber());
			dto.setCurrency(s.getCurrency());
			dto.setLastPrice(s.getLastPrice());
			dto.setPreviousPrice(s.getPreviousPrice());
			dto.setEquityCategory(s.getEquityCategory());
			lisDto.add(dto);
		}
		return lisDto;
		
	}
	
	
	
	
	@GetMapping("/industry/{industry}")
	public List<SecurityResponseDto> getByIndustry(@PathVariable("industry") String industry,
											String description){

		List<Security> list = securityRepository.getByIndusty(industry, Sort.by("description").ascending());
		
		List<SecurityResponseDto> lisDto = new ArrayList<>();
		for(Security s : list) {
			SecurityResponseDto dto = new SecurityResponseDto();
			dto.setSymbol(s.getSymbol());
			dto.setDescription(s.getDescription());
			dto.setSector(s.getSector());
			dto.setIndustry(s.getIndustry());
			dto.setExchange(s.getExchange());
			dto.setIsinNumber(s.getIsinNumber());
			dto.setCurrency(s.getCurrency());
			dto.setLastPrice(s.getLastPrice());
			dto.setPreviousPrice(s.getPreviousPrice());
			dto.setEquityCategory(s.getEquityCategory());
			lisDto.add(dto);
		}
		return lisDto; 
		
	}
	
	@PutMapping("/update/{lastPrice}/{symbol}")
	public ResponseEntity<String> updateLastPrice(@PathVariable("lastPrice") String lastPrice,
													@PathVariable("symbol") String symbol){
		double lprice = Double.parseDouble(lastPrice);
		calculationService.updateSecurityLastPrice(symbol, lprice);
		Optional<Security> optional = securityRepository.findBySymbol(symbol);
		if(!optional.isPresent())
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Symbol is Invalid");
		Security security = optional.get();
		security.setLastPrice(lastPrice);
	
		securityRepository.save(security);
		return ResponseEntity.status(HttpStatus.OK).body("Last Price Status Updated");
		
	}
	
	@PutMapping("/real/update/{lastPrice}/{symbol}")
	public ResponseEntity<String> updateLastPriceSecurity(@PathVariable("lastPrice") String lastPrice,
													@PathVariable("symbol") String symbol){
		Optional<Price> optional = priceRepository.findBySymbol(symbol);
		if(!optional.isPresent())
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Symbol is Invalid");
		Price price = optional.get();
		
		priceRepository.save(price);
		return ResponseEntity.status(HttpStatus.OK).body("Last Price Status Updated");
		
	}
	
	


}
