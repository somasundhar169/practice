package com.spring.securityMaster.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Composition {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@ManyToOne
	private Portfolio portfolio;
	
	@ManyToOne
	private Security security;
	
	private LocalDate transactionDate;
	private Double quantity;
	private Double price;
	private Double valueOfSecurity;
	private String transactionType;
	@ManyToOne
	private Asset asset;
	private Double actualAllocation;
	public Composition(Long id, Portfolio portfolio, Security security, LocalDate transactionDate, Double quantity,
			Double price, Double valueOfSecurity, String transactionType, Asset asset, Double actualAllocation) {
		super();
		this.id = id;
		this.portfolio = portfolio;
		this.security = security;
		this.transactionDate = transactionDate;
		this.quantity = quantity;
		this.price = price;
		this.valueOfSecurity = valueOfSecurity;
		this.transactionType = transactionType;
		this.asset = asset;
		this.actualAllocation = actualAllocation;
	}
	public Composition() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Portfolio getPortfolio() {
		return portfolio;
	}
	public void setPortfolio(Portfolio portfolio) {
		this.portfolio = portfolio;
	}
	public Security getSecurity() {
		return security;
	}
	public void setSecurity(Security security) {
		this.security = security;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getValueOfSecurity() {
		return valueOfSecurity;
	}
	public void setValueOfSecurity(Double valueOfSecurity) {
		this.valueOfSecurity = valueOfSecurity;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Asset getAsset() {
		return asset;
	}
	public void setAsset(Asset asset) {
		this.asset = asset;
	}
	public Double getActualAllocation() {
		return actualAllocation;
	}
	public void setActualAllocation(Double actualAllocation) {
		this.actualAllocation = actualAllocation;
	}
	@Override
	public String toString() {
		return "Composition [id=" + id + ", portfolio=" + portfolio + ", security=" + security + ", transactionDate="
				+ transactionDate + ", quantity=" + quantity + ", price=" + price + ", valueOfSecurity="
				+ valueOfSecurity + ", transactionType=" + transactionType + ", asset=" + asset + ", actualAllocation="
				+ actualAllocation + "]";
	}
	
	
}
