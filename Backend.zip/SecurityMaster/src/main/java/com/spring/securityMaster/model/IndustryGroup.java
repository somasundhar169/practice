package com.spring.securityMaster.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class IndustryGroup {


	@Id
	private String id;

	private String industryGroupName;

	public IndustryGroup() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IndustryGroup(String id, String industryGroupName) {
		super();
		this.id = id;
		this.industryGroupName = industryGroupName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIndustryGroupName() {
		return industryGroupName;
	}

	public void setIndustryGroupName(String industryGroupName) {
		this.industryGroupName = industryGroupName;
	}

	@Override
	public String toString() {
		return "IndustryGroup [id=" + id + ", industryGroupName=" + industryGroupName + "]";
	}

	

}
