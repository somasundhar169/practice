package com.spring.securityMaster.controller;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.securityMaster.dto.CompositionDto;
import com.spring.securityMaster.dto.CompositionResponseDto;
import com.spring.securityMaster.dto.ErrorResponse;
import com.spring.securityMaster.dto.SecurityResponseDto;
import com.spring.securityMaster.model.Asset;
import com.spring.securityMaster.model.AssetHoldings;
import com.spring.securityMaster.model.Composition;
import com.spring.securityMaster.model.Portfolio;
import com.spring.securityMaster.model.Security;
import com.spring.securityMaster.repository.AssetHoldingsRepository;
import com.spring.securityMaster.repository.AssetRepository;
import com.spring.securityMaster.repository.CompositionRepository;
import com.spring.securityMaster.repository.PortfolioRepository;
import com.spring.securityMaster.repository.SecurityRepository;
import com.spring.securityMaster.service.CalculationService;

@RestController
@RequestMapping("/master")
@CrossOrigin(origins = {"http://localhost:2890"})
public class CompositionController {

	@Autowired
	private CompositionRepository compositionRepository;
	
	@Autowired
	private PortfolioRepository portfolioRepository;
	
	@Autowired
	private SecurityRepository securityRepository;
	
	@Autowired
	private CalculationService calculationService;
	
	@Autowired 
	private AssetRepository assetRepository;
	
	@Autowired
	private AssetHoldingsRepository assetHoldingsRepository;
	
	@PostMapping("/insert/composition")
	public ResponseEntity<?> postComposition(@RequestBody CompositionDto compositionDto) {
		Composition composition = new Composition();
		Portfolio portfolio = portfolioRepository.findbyName(compositionDto.getPortfolioName());
		Asset asset = assetRepository.findById(compositionDto.getAssetId()).orElse(null);
		Security security = securityRepository.findBySymbol1(compositionDto.getSymbol());
		System.out.println(security);
		System.out.println(portfolio);
		System.out.println(asset);
		
		
		System.out.println("error");
		if (portfolio != null && asset != null) {
			System.out.println("error");
			Composition composition1 = compositionRepository.findByPortfolioAndAsset(compositionDto.getPortfolioName(), compositionDto.getAssetId(), compositionDto.getSymbol());
			System.out.println(composition1);
		if (composition1 != null) {

		} else {
			composition1 = new Composition();
			composition1.setPortfolio(portfolio);
			composition1.setAsset(asset);
			composition1.setSecurity(security);
			composition1.setQuantity(compositionDto.getQuantity());
			composition1.setTransactionType("Buy");
			composition1.setActualAllocation(compositionDto.getActualAllocation());

			double lastPrice = Double.parseDouble(security.getLastPrice());
			composition1.setPrice(lastPrice);
			
			double valueOfSecurity = composition1.getPrice() * composition1.getQuantity();
			composition1.setValueOfSecurity(valueOfSecurity);
			
			LocalDate currentDate = LocalDate.now();
			composition1.setTransactionDate(currentDate);
			
			double currentValue = composition1.getPortfolio().getCurrentValue() + composition1.getValueOfSecurity();
			composition1.getPortfolio().setCurrentValue(currentValue);
			composition1.getPortfolio().setInvestedAmount(currentValue);
			
			double investmentValue = composition1.getPortfolio().getRemainingBalance();
			double remainingBalence = investmentValue - currentValue;
			if(remainingBalence < 0) {
				ErrorResponse errorResponse = new ErrorResponse();
				errorResponse.setMessage("Invested amount exceeds remaining balance");
				return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
//				throw new RuntimeException("Invested amount exceeds remaining balance");
			}
			
			composition1.getPortfolio().setRemainingBalance(remainingBalence);
			}
			
		portfolioRepository.save(composition1.getPortfolio());
		compositionRepository.save(composition1);
		
		}
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setMessage("Composition Posted");
		
		
		
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
}
		
	@GetMapping("/get/composition/{portfolioName}")
	public List<CompositionResponseDto> getCompositionByPortfolioName(@PathVariable("portfolioName") String portfolioName) {
		List<Composition> list = compositionRepository.findByPortfolioName(portfolioName);
		List<CompositionResponseDto> listDto = new ArrayList<>();
		for(Composition composition : list) {
			CompositionResponseDto dto = new CompositionResponseDto();
			
			String assetId = composition.getAsset().getId();
			String themeName = composition.getPortfolio().getTheme().getThemeName();
			AssetHoldings assetHoldings = assetHoldingsRepository.findByAssetIdAndThemeName(assetId, themeName);
			
			dto.setSymbol(composition.getSecurity().getSymbol());
			dto.setCurrency(composition.getSecurity().getCurrency());
			dto.setAllocation(assetHoldings.getAllocation());
			dto.setBenchmark(composition.getPortfolio().getBenchmark());
			dto.setDescription(composition.getSecurity().getDescription());
			dto.setEquityCategory(composition.getSecurity().getEquityCategory());
			dto.setExchange(composition.getPortfolio().getExchange());
			dto.setPortfolioName(composition.getPortfolio().getPortfolioName());
			dto.setPrice(composition.getPrice());
			dto.setQuantity(composition.getQuantity());
			dto.setTransactinDate(composition.getTransactionDate());
			dto.setValueOfSecurity(composition.getValueOfSecurity());
			dto.setAssetClass(composition.getAsset().getAssetClass());
			dto.setAssetSubClass(composition.getAsset().getAssetSubClass());
			dto.setRisk(composition.getAsset().getRisk());
			dto.setInvestmentHorizon(composition.getAsset().getInvestmentHorizon());
			dto.setLiquidity(composition.getAsset().getLiquidity());
			dto.setTransactionType(composition.getTransactionType());
			dto.setActualAllocation(composition.getActualAllocation());
			listDto.add(dto);
		}
		return listDto;
	}
	@GetMapping("/get/{id}")
	public CompositionResponseDto getById(@PathVariable("id") Long id) {
		
		Composition composition = compositionRepository.getById(id);
		
		Optional<Composition> optional = compositionRepository.findById(id);
		if(!optional.isPresent()) {
			throw new RuntimeException("id is invalid");
		}
		CompositionResponseDto dto = new CompositionResponseDto();
		
		dto.setSymbol(composition.getSecurity().getSymbol());
		dto.setCurrency(composition.getSecurity().getCurrency());
//		dto.setAllocation(composition.getAllocation());
		dto.setBenchmark(composition.getPortfolio().getBenchmark());
		dto.setDescription(composition.getSecurity().getDescription());
		dto.setEquityCategory(composition.getSecurity().getEquityCategory());
		dto.setExchange(composition.getPortfolio().getExchange());
		dto.setPortfolioName(composition.getPortfolio().getPortfolioName());
		dto.setPrice(composition.getPrice());
		dto.setQuantity(composition.getQuantity());
		dto.setTransactinDate(composition.getTransactionDate());
		dto.setValueOfSecurity(composition.getValueOfSecurity());
		
		return dto;
		
		
	}
	
	
}
