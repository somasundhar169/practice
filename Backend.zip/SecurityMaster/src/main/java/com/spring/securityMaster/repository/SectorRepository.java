package com.spring.securityMaster.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.securityMaster.model.Sectors;

public interface SectorRepository extends JpaRepository<Sectors, String>{

}
