package com.spring.securityMaster.model;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.spring.securityMaster.enums.PortfolioCurrency;
import com.spring.securityMaster.enums.PortfolioExchange;
import com.spring.securityMaster.enums.PortfolioThemeOfInvestment;

@Entity
public class Portfolio {

	private static final Composition[] compositions = null;

	@Id
	private String portfolioName;
	
	@Enumerated(EnumType.STRING)
	private PortfolioCurrency currency;
	
	@Enumerated(EnumType.STRING)
	private PortfolioExchange exchange;
	
	private String benchmark;
	
	@ManyToOne
	private Theme theme;
	
	private Double remainingBalance;
	
	private String rebalancingFrequency;
	
	private Double investmentValue;
	
	private Double currentValue;
	
	private double remainingAllocation;
	private Double investedAmount;
	
	private Double netEarnings;
	
	private String pAndLStatement;
	
	private String status;

	public Portfolio(String portfolioName, PortfolioCurrency currency, PortfolioExchange exchange, String benchmark,
			Theme theme, Double remainingBalance, String rebalancingFrequency, Double investmentValue,
			Double currentValue, double remainingAllocation, Double investedAmount, Double netEarnings,
			String pAndLStatement, String status) {
		super();
		this.portfolioName = portfolioName;
		this.currency = currency;
		this.exchange = exchange;
		this.benchmark = benchmark;
		this.theme = theme;
		this.remainingBalance = remainingBalance;
		this.rebalancingFrequency = rebalancingFrequency;
		this.investmentValue = investmentValue;
		this.currentValue = currentValue;
		this.remainingAllocation = remainingAllocation;
		this.investedAmount = investedAmount;
		this.netEarnings = netEarnings;
		this.pAndLStatement = pAndLStatement;
		this.status = status;
	}

	public Portfolio() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public PortfolioCurrency getCurrency() {
		return currency;
	}

	public void setCurrency(PortfolioCurrency currency) {
		this.currency = currency;
	}

	public PortfolioExchange getExchange() {
		return exchange;
	}

	public void setExchange(PortfolioExchange exchange) {
		this.exchange = exchange;
	}

	public String getBenchmark() {
		return benchmark;
	}

	public void setBenchmark(String benchmark) {
		this.benchmark = benchmark;
	}

	public Theme getTheme() {
		return theme;
	}

	public void setTheme(Theme theme) {
		this.theme = theme;
	}

	public Double getRemainingBalance() {
		return remainingBalance;
	}

	public void setRemainingBalance(Double remainingBalance) {
		this.remainingBalance = remainingBalance;
	}

	public String getRebalancingFrequency() {
		return rebalancingFrequency;
	}

	public void setRebalancingFrequency(String rebalancingFrequency) {
		this.rebalancingFrequency = rebalancingFrequency;
	}

	public Double getInvestmentValue() {
		return investmentValue;
	}

	public void setInvestmentValue(Double investmentValue) {
		this.investmentValue = investmentValue;
	}

	public Double getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(Double currentValue) {
		this.currentValue = currentValue;
	}

	public double getRemainingAllocation() {
		return remainingAllocation;
	}

	public void setRemainingAllocation(double remainingAllocation) {
		this.remainingAllocation = remainingAllocation;
	}

	public Double getInvestedAmount() {
		return investedAmount;
	}

	public void setInvestedAmount(Double investedAmount) {
		this.investedAmount = investedAmount;
	}

	public Double getNetEarnings() {
		return netEarnings;
	}

	public void setNetEarnings(Double netEarnings) {
		this.netEarnings = netEarnings;
	}

	public String getpAndLStatement() {
		return pAndLStatement;
	}

	public void setpAndLStatement(String pAndLStatement) {
		this.pAndLStatement = pAndLStatement;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static Composition[] getCompositions() {
		return compositions;
	}

	@Override
	public String toString() {
		return "Portfolio [portfolioName=" + portfolioName + ", currency=" + currency + ", exchange=" + exchange
				+ ", benchmark=" + benchmark + ", theme=" + theme + ", remainingBalance=" + remainingBalance
				+ ", rebalancingFrequency=" + rebalancingFrequency + ", investmentValue=" + investmentValue
				+ ", currentValue=" + currentValue + ", remainingAllocation=" + remainingAllocation
				+ ", investedAmount=" + investedAmount + ", netEarnings=" + netEarnings + ", pAndLStatement="
				+ pAndLStatement + ", status=" + status + "]";
	}

	
	
}
			

