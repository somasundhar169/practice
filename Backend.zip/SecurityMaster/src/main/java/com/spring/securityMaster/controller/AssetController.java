package com.spring.securityMaster.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.securityMaster.dto.AssetResponseDto;
import com.spring.securityMaster.model.Asset;
import com.spring.securityMaster.repository.AssetRepository;

@RestController
@RequestMapping("/master")
@CrossOrigin(origins = {"http://localhost:2890"})
public class AssetController {

	@Autowired
	private AssetRepository assetRepository;
	
	@PostMapping("/post/asset")
	public Asset insertAsset(@RequestBody Asset asset) {
		return assetRepository.save(asset);
	}
	@GetMapping("/get/all/asset")
	public List<Asset> getAllAssetClass() {
		return assetRepository.findAll();
	}
	
//	@GetMapping("/theme/{themeName}")
//	public List<AssetResponseDto> getAssetByThemeName(@PathVariable("themeName") String themeName ) {
//		List<Asset> list = assetRepository.findByThemeName(themeName);
//		
//		List<AssetResponseDto> listDto = new ArrayList<>();
//		
//		for(Asset a : list) {
//			AssetResponseDto dto = new AssetResponseDto();
//			dto.setId(a.getId());
//			dto.setAssetClass(a.getAssetClass());
//			dto.setAssetSubClass(a.getAssetSubClass());
//			dto.setRisk(a.getRisk());
//			dto.setInvestmentHorizon(a.getInvestmentHorizon());
//			dto.setLiquidity(a.getLiquidity());
//			dto.setReturns(a.getReturns());
//			listDto.add(dto);
//		}
//		return listDto;
//		
//	}
	
	
}
