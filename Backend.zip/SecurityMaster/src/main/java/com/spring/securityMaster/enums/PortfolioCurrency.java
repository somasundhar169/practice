package com.spring.securityMaster.enums;

public enum PortfolioCurrency {
	INR, USD
}
