package com.spring.securityMaster.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.securityMaster.model.Price;
import com.spring.securityMaster.model.Security;

public interface PriceRepository extends JpaRepository<Price, String>{

	@Query("select p from Price p where p.security.symbol=?1")
	Optional<Price> findBySymbol(String symbol);
	
	@Query("select p from Price p where p.security.isinNumber=?1")
	Optional<Price> findByIsinNumber(String isinNumber);

	@Query("select p from Price p where p.security.sector LIKE %?1%")
	List<Price> getBySector(String sector);
	
	@Query("select p from Price p where p.security.industry LIKE %?1%")
	List<Price> getByIdustry(String industry);
}
