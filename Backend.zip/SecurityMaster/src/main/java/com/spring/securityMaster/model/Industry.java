package com.spring.securityMaster.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Industry {

	@Id
	private String id;

	private String industryName;

	public Industry(String id, String industryName) {
		super();
		this.id = id;
		this.industryName = industryName;
	}

	public Industry() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIndustryName() {
		return industryName;
	}

	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}

	@Override
	public String toString() {
		return "Industry [id=" + id + ", industryName=" + industryName + "]";
	}
	
	
}
