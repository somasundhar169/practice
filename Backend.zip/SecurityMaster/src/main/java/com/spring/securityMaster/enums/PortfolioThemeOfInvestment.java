package com.spring.securityMaster.enums;

public enum PortfolioThemeOfInvestment {
	CONSERVATIVE, AGGRESSIVE, VERYAGGRESSIVE
}
