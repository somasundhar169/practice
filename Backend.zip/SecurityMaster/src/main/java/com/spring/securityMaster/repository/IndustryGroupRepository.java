package com.spring.securityMaster.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.securityMaster.model.IndustryGroup;

public interface IndustryGroupRepository extends JpaRepository<IndustryGroup, String>{

}
