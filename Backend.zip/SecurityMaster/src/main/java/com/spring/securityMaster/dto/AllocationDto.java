package com.spring.securityMaster.dto;

public class AllocationDto {
	private double allocation;

	public double getAllocation() {
		return allocation;
	}

	public void setAllocation(double allocation) {
		this.allocation = allocation;
	}
	
}
