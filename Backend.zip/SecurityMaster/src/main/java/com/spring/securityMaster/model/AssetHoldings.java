package com.spring.securityMaster.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class AssetHoldings {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@ManyToOne
	private Asset asset;
	
	@ManyToOne
	private Theme theme;
	
	private double allocation;

	public AssetHoldings(Long id, Asset asset, Theme theme, double allocation) {
		super();
		this.id = id;
		this.asset = asset;
		this.theme = theme;
		this.allocation = allocation;
	}

	public AssetHoldings() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Asset getAsset() {
		return asset;
	}

	public void setAsset(Asset asset) {
		this.asset = asset;
	}

	public Theme getTheme() {
		return theme;
	}

	public void setTheme(Theme theme) {
		this.theme = theme;
	}

	public double getAllocation() {
		return allocation;
	}

	public void setAllocation(double allocation) {
		this.allocation = allocation;
	}

	@Override
	public String toString() {
		return "AssetHoldings [id=" + id + ", asset=" + asset + ", theme=" + theme + ", allocation=" + allocation + "]";
	}
	
	
}
