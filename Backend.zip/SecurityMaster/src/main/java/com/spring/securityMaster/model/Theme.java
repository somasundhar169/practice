package com.spring.securityMaster.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Theme {

	@Id
	private String themeName;

	public Theme(String themeName) {
		super();
		this.themeName = themeName;
	}

	public Theme() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getThemeName() {
		return themeName;
	}

	public void setThemeName(String themeName) {
		this.themeName = themeName;
	}

	@Override
	public String toString() {
		return "Theme [themeName=" + themeName + "]";
	}
	
	

	
}
