package com.spring.securityMaster.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Price {

	@Id
	private String id;
	@OneToOne
	private Security security;
	private String lastPrice;
	private String date;
	public Price(String id, Security security, String lastPrice, String date) {
		super();
		this.id = id;
		this.security = security;
		this.lastPrice = lastPrice;
		this.date = date;
	}
	public Price() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Security getSecurity() {
		return security;
	}
	public void setSecurity(Security security) {
		this.security = security;
	}
	public String getLastPrice() {
		return lastPrice;
	}
	public void setLastPrice(String lastPrice) {
		this.lastPrice = lastPrice;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Price [id=" + id + ", security=" + security + ", lastPrice=" + lastPrice + ", date=" + date + "]";
	}
	
	
	
	
	
	
}
