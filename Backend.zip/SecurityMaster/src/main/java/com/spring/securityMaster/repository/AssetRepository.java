package com.spring.securityMaster.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.securityMaster.model.Asset;

public interface AssetRepository extends JpaRepository<Asset, String>{

	@Query("select a from Asset a where a.id=?1")
	Object findBy(String assetId);

//	@Query("select a from Asset a where a.theme.themeName=?1")
//	List<Asset> findByThemeName(String themeName);

}
