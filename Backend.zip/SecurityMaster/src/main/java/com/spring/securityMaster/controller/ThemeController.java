package com.spring.securityMaster.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.securityMaster.dto.AssetResponseDto;
import com.spring.securityMaster.model.Asset;
import com.spring.securityMaster.model.Theme;
import com.spring.securityMaster.repository.ThemeRepository;

@RestController
@RequestMapping("/master")
@CrossOrigin(origins = {"http://localhost:2890"})
public class ThemeController {

	@Autowired
	private ThemeRepository themeRepository;
	
	
	@PostMapping("/theme/post")
	public Theme postTheme(@RequestBody Theme theme) {
		return themeRepository.save(theme);
		
	}
	
	@GetMapping("/get/all/theme")
	public List<Theme> getAllTheme() {
		return themeRepository.findAll();
	}
	
}
