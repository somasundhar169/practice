package com.spring.securityMaster.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
@Entity
public class Security {

	@Id
	private String symbol;
	private String description;

	private String sector;

	private String industry;

	private String exchange;

	private String isinNumber;

	@Column(name = "Currency")
	private String currency;
	
	private String lastPrice;
	
	private String previousPrice;
	
	private String timeStamp;
	
	private String equityCategory;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "asset_id")
	private Asset asset;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sub_industry_id")
	private SubIndustry subIndustry;

	public Security(String symbol, String description, String sector, String industry, String exchange,
			String isinNumber, String currency, String lastPrice, String previousPrice, String timeStamp,
			String equityCategory, Asset asset, SubIndustry subIndustry) {
		super();
		this.symbol = symbol;
		this.description = description;
		this.sector = sector;
		this.industry = industry;
		this.exchange = exchange;
		this.isinNumber = isinNumber;
		this.currency = currency;
		this.lastPrice = lastPrice;
		this.previousPrice = previousPrice;
		this.timeStamp = timeStamp;
		this.equityCategory = equityCategory;
		this.asset = asset;
		this.subIndustry = subIndustry;
	}

	public Security() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getExchange() {
		return exchange;
	}

	public void setExchange(String exchange) {
		this.exchange = exchange;
	}

	public String getIsinNumber() {
		return isinNumber;
	}

	public void setIsinNumber(String isinNumber) {
		this.isinNumber = isinNumber;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getLastPrice() {
		return lastPrice;
	}

	public void setLastPrice(String lastPrice) {
		this.lastPrice = lastPrice;
	}

	public String getPreviousPrice() {
		return previousPrice;
	}

	public void setPreviousPrice(String previousPrice) {
		this.previousPrice = previousPrice;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getEquityCategory() {
		return equityCategory;
	}

	public void setEquityCategory(String equityCategory) {
		this.equityCategory = equityCategory;
	}

	public Asset getAsset() {
		return asset;
	}

	public void setAsset(Asset asset) {
		this.asset = asset;
	}

	public SubIndustry getSubIndustry() {
		return subIndustry;
	}

	public void setSubIndustry(SubIndustry subIndustry) {
		this.subIndustry = subIndustry;
	}

	@Override
	public String toString() {
		return "Security [symbol=" + symbol + ", description=" + description + ", sector=" + sector + ", industry="
				+ industry + ", exchange=" + exchange + ", isinNumber=" + isinNumber + ", currency=" + currency
				+ ", lastPrice=" + lastPrice + ", previousPrice=" + previousPrice + ", timeStamp=" + timeStamp
				+ ", equityCategory=" + equityCategory + ", asset=" + asset + ", subIndustry=" + subIndustry + "]";
	}
	
	
}