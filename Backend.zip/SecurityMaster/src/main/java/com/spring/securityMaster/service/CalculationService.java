package com.spring.securityMaster.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.securityMaster.model.Asset;
import com.spring.securityMaster.model.Composition;
import com.spring.securityMaster.model.Portfolio;
import com.spring.securityMaster.model.Security;
import com.spring.securityMaster.repository.AssetRepository;
import com.spring.securityMaster.repository.CompositionRepository;
import com.spring.securityMaster.repository.PortfolioRepository;
import com.spring.securityMaster.repository.SecurityRepository;

@Service
public class CalculationService {
	
	@Autowired
	private SecurityRepository securityRepository;
	
	@Autowired
	private PortfolioRepository portfolioRepository;
	
	@Autowired
	private CompositionRepository compositionRepository;
	
	@Autowired 
	private AssetRepository assetRepository;

	public void updateSecurityLastPrice(String symbol, Double lastPrice) {

		// Update the Security object with the new last price
		Security security = securityRepository.findById(symbol).orElse(null);
		if (security != null) {
		security.setLastPrice(String.valueOf(lastPrice));
		securityRepository.save(security);
		}

		// Update the Composition objects with the new price and valueOfSecurity
		List<Composition> compositionsToUpdate = compositionRepository.findBySecuritySymbol(symbol);
		for (Composition composition : compositionsToUpdate) {
		composition.setPrice(lastPrice);
		composition.setValueOfSecurity(lastPrice * composition.getQuantity());
		compositionRepository.save(composition);
		}

		// Update the Portfolio objects with the new currentValue
		List<Composition> allCompositions = compositionRepository.findByPortfolioName(compositionsToUpdate.get(0).getPortfolio().getPortfolioName());
		Double totalValue = allCompositions.stream().mapToDouble(Composition::getValueOfSecurity).sum();
		Portfolio portfolio = portfolioRepository.findById(allCompositions.get(0).getPortfolio().getPortfolioName()).orElse(null);
		if (portfolio != null) {
		portfolio.setCurrentValue(totalValue);
		portfolioRepository.save(portfolio);
		
		//Upadating pAndLStatement and netEarnings
		double netEarnings = portfolio.getCurrentValue() - portfolio.getInvestedAmount();
		portfolio.setNetEarnings(netEarnings);
		
		if(netEarnings < 0) {
			portfolio.setpAndLStatement("Loss");
		}else {
			portfolio.setpAndLStatement("Profit");
		}
		portfolioRepository.save(portfolio);
	}
	}

		// other methods as needed

//	public void addCompositionData(String portfolioName, String assetName, Double quantity, double allocation, String symbol) {
//		Portfolio portfolio = portfolioRepository.findById(portfolioName).orElse(null);
//		Asset asset = assetRepository.findById(assetName).orElse(null);
//		Security symbol1 = securityRepository.findById(symbol1);
//		if (portfolio != null && asset != null) {
//		Composition composition = compositionRepository.findByPortfolioAndAsset(portfolioName, assetName, symbol1);
//		if (composition != null) {
//		double totalAllocation = portfolio.getRemainingAllocation() + composition.getAllocation();
//		composition.setAllocation(allocation * quantity / (double)composition.getQuantity());
//		portfolio.setRemainingAllocation(totalAllocation - composition.getAllocation());
//		} else {
//		composition = new Composition();
//		composition.setPortfolio(portfolio);
//		composition.setAsset(asset);
//		composition.setQuantity(quantity);
//		composition.setAllocation(allocation);
//		portfolio.setRemainingAllocation(portfolio.getRemainingAllocation() - allocation);
//		}
//		compositionRepository.save(composition);
//		portfolioRepository.save(portfolio);
//		}
//		}
}

