package com.spring.securityMaster.enums;

public enum AssetClassRisk {
	HIGH, MEDIUM, LOW
}
