package com.spring.securityMaster.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.securityMaster.model.Theme;

public interface ThemeRepository extends JpaRepository<Theme, String>{

	@Query("select t from Theme t where t.themeName=?1")
	Theme findByName(String theme);

}
