package com.spring.securityMaster.model;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.spring.securityMaster.enums.AssetClassRisk;

@Entity
public class Asset {
	
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private String id;
	private String assetClass;
	private String assetSubClass;
	
	private String risk;
	private String investmentHorizon;
	private String returns;
	private String liquidity;
	public Asset(String id, String assetClass, String assetSubClass, String risk, String investmentHorizon,
			String returns, String liquidity) {
		super();
		this.id = id;
		this.assetClass = assetClass;
		this.assetSubClass = assetSubClass;
		this.risk = risk;
		this.investmentHorizon = investmentHorizon;
		this.returns = returns;
		this.liquidity = liquidity;
	}
	public Asset() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getAssetSubClass() {
		return assetSubClass;
	}
	public void setAssetSubClass(String assetSubClass) {
		this.assetSubClass = assetSubClass;
	}
	public String getRisk() {
		return risk;
	}
	public void setRisk(String risk) {
		this.risk = risk;
	}
	public String getInvestmentHorizon() {
		return investmentHorizon;
	}
	public void setInvestmentHorizon(String investmentHorizon) {
		this.investmentHorizon = investmentHorizon;
	}
	public String getReturns() {
		return returns;
	}
	public void setReturns(String returns) {
		this.returns = returns;
	}
	public String getLiquidity() {
		return liquidity;
	}
	public void setLiquidity(String liquidity) {
		this.liquidity = liquidity;
	}
	@Override
	public String toString() {
		return "Asset [id=" + id + ", assetClass=" + assetClass + ", assetSubClass=" + assetSubClass + ", risk=" + risk
				+ ", investmentHorizon=" + investmentHorizon + ", returns=" + returns + ", liquidity=" + liquidity
				+ "]";
	}
	
	

	
}
