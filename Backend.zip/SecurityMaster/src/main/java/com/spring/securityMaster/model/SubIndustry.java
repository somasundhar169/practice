package com.spring.securityMaster.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class SubIndustry {

	@Id
	private String id;
	private String subIndustryName;

	@ManyToOne()
	@JoinColumn(name = "industry_id")
	private Industry industry;

	@ManyToOne()
	@JoinColumn(name = "industry_group_id")
	private IndustryGroup industryGroup;

	@ManyToOne()
	@JoinColumn(name = "sector_id")
	private Sectors sectors;

	public SubIndustry(String id, String subIndustryName, Industry industry, IndustryGroup industryGroup,
			Sectors sectors) {
		super();
		this.id = id;
		this.subIndustryName = subIndustryName;
		this.industry = industry;
		this.industryGroup = industryGroup;
		this.sectors = sectors;
	}

	public SubIndustry() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSubIndustryName() {
		return subIndustryName;
	}

	public void setSubIndustryName(String subIndustryName) {
		this.subIndustryName = subIndustryName;
	}

	public Industry getIndustry() {
		return industry;
	}

	public void setIndustry(Industry industry) {
		this.industry = industry;
	}

	public IndustryGroup getIndustryGroup() {
		return industryGroup;
	}

	public void setIndustryGroup(IndustryGroup industryGroup) {
		this.industryGroup = industryGroup;
	}

	public Sectors getSectors() {
		return sectors;
	}

	public void setSectors(Sectors sectors) {
		this.sectors = sectors;
	}

	@Override
	public String toString() {
		return "SubIndustry [id=" + id + ", subIndustryName=" + subIndustryName + ", industry=" + industry
				+ ", industryGroup=" + industryGroup + ", sectors=" + sectors + "]";
	}
	
	
}
