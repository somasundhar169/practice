package com.spring.securityMaster.controller;

 

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

 
import com.spring.securityMaster.dto.PortfolioDto;
import com.spring.securityMaster.dto.SecurityResponseDto;
import com.spring.securityMaster.model.Asset;
import com.spring.securityMaster.model.Industry;
import com.spring.securityMaster.model.IndustryGroup;
import com.spring.securityMaster.model.Portfolio;
import com.spring.securityMaster.model.Sectors;
import com.spring.securityMaster.model.Security;
import com.spring.securityMaster.model.SubIndustry;
import com.spring.securityMaster.repository.IndustryGroupRepository;
import com.spring.securityMaster.repository.IndustryRepository;
import com.spring.securityMaster.repository.SectorRepository;
import com.spring.securityMaster.repository.SubIndustryRepository;

 

@RestController
@RequestMapping("/subindustry")
@CrossOrigin(origins = {"http://localhost:2890"})
public class SubIndustryController {

    @Autowired
    private SubIndustryRepository subIndustryRepository;

    @Autowired
    private IndustryRepository industryRepository;

    @Autowired
    private IndustryGroupRepository industryGroupRepository;

    @Autowired
    private  SectorRepository  sectorRepository;


    @GetMapping("/getall/subindustry")
    public List<SubIndustry> getAllSubIndustry() {
        return subIndustryRepository.findAll();

    }
    @GetMapping("/get/{id}")
    public SubIndustry getBySubIndId(@PathVariable("id") String subIndustryId){
        Optional<SubIndustry> list=subIndustryRepository.findById(subIndustryId);
        if(!list.isPresent())
            throw new RuntimeException("invalid id");
        SubIndustry s=list.get();
        return s;    

    }
    @PutMapping("put/{subIndustryName}/{id}")
    public ResponseEntity<String> updatSubIndustry(@PathVariable("subIndustryName") String subIndustryName, @PathVariable("id")String id){
    Optional<SubIndustry> optional=subIndustryRepository.findById(id);
    if(!optional.isPresent())
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid id");
    SubIndustry sub=optional.get();
    sub.setSubIndustryName(subIndustryName);
    subIndustryRepository.save(sub);
    return ResponseEntity.status(HttpStatus.OK).body("Sub industry name updated");


    }
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<String> deleteById(@PathVariable("id") String id){
//    sectorRepository.deleteById(id);
//    return  ResponseEntity.status(HttpStatus.OK).body("deleted successfully");
//    }
    @DeleteMapping("/delete/{id}")

 

    public ResponseEntity<String> deleteById(@PathVariable("id") String id){

 

    subIndustryRepository.deleteById(id);

 

    return ResponseEntity.status(HttpStatus.OK).body("deleted successfully");

 

    }
    @PostMapping("/post/sector")

 

    public Sectors insertSector(@RequestBody Sectors sector) {

 

    return sectorRepository.save(sector);

 

    }


//    @GetMapping("/allindustries/{id}")
//    public SubIndustryDto getBySubIndustry(@PathVariable("id") String subIndustryId) {
//        Optional<SubIndustry> optional = subIndustryRepository.findBysubIndustryId(subIndustryId);
//        System.out.println(optional);
//        if(!optional.isPresent())
//            throw new RuntimeException("SubIndustry Id is invalid");
//        SubIndustryDto dto = new SubIndustryDto();
//        SubIndustry s = optional.get();
//        dto.setSubIndustryId(s.getSubIndustryId());
//        dto.setSubIndustryName(s.getSubIndustryName());
//        dto.setIndustryId(s.getIndustry().getIndustryId());
//        dto.setIndustryGroupId(s.getIndustryGroup().getIndustryGroupId());
//        dto.setSectorId(s.getSectors().getSectorId());
//        
//        return dto;
//    }



    // To get all industries

//    @GetMapping("/get/all/industry")
//    public List<Industry> getAllindustries() {
//        return industryRepository.findAll();
//    }
//    
//    // To get all Industry groups
//    
//    @GetMapping("/get/all/industrygroup")
//    public List<IndustryGroup> getAllindustryGroups() {
//        return industryGroupRepository.findAll();
//    }
//    
//    //To get all sectors
//    
//    @GetMapping("/get/all/sectors")
//    public List<Sectors> getAllSectors() {
//        return sectorRepository.findAll();
//    }
//    
//    
//    
//    // without sector id displays 
//
//    @GetMapping("/indgrp/{id}")
//    public List<IndustryGroupDto> getBySectorId(@PathVariable("id") String sectorId, String industryName){
//                                            
//
//        List<IndustryGroup> list = industryGroupRepository.getBySectorId(sectorId);
//        
//        List<IndustryGroupDto> lisDto = new ArrayList<>();
//        for(IndustryGroup s : list) {
//            IndustryGroupDto dto = new IndustryGroupDto();
//            dto.setIndustryGroupId(s.getIndustryGroupId());
//            dto.setIndustryGroupName(s.getIndustryGroupName());
//            //dto.setSectorId(s.getSectorId());
//
//            lisDto.add(dto);
//        }
//        return lisDto; 
//    }
//    
//    //with id displays industry group
//    @GetMapping("/ind/{id}")
//    public List<Industry> getByIndustryGroupId(@PathVariable("id") String industryGroupId, String industryName){
//                                            
//
//        List<Industry> list = industryRepository.getByIndGrpId(industryGroupId);
//        
//        List<Industry> lisDto = new ArrayList<>();
//        for(Industry s : list) {
//            Industry dto = new Industry();
//            dto.setIndustryId(s.getIndustryId());
//            dto.setIndustryName(s.getIndustryName());
////            dto.setIndustryGroupId(s.getIndustryGroupId());
//            
//
//            lisDto.add(dto);
//        }
//        return lisDto; 
//    }
//    
//    // without indgrp id 
//    
//    @GetMapping("/i/ind/{id}")
//    public List<IndustryDto> getByIndGroupId(@PathVariable("id") String industryGroupId, String industryName){
//        
//
//        List<Industry> list = industryRepository.getByIndGrpId(industryGroupId);
//        
//        List<IndustryDto> lisDto = new ArrayList<>();
//        for(Industry s : list) {
//            IndustryDto dto = new IndustryDto();
//            dto.setIndustryId(s.getIndustryId());
//            dto.setIndustryName(s.getIndustryName());
//            //dto.setIndustryGroupId(s.getIndustryGroupId());
//            
//
//            lisDto.add(dto);
//        }
//        return lisDto; 
//    }
//    
////    @GetMapping("/i/subind/{id}")
////    public List<SubIndustryDto> getBySubIndId(@PathVariable("id") String subIndustryId, String subIndustryName){
////        
////
////        List<SubIndustry> list = subIndustryRepository.getBySubIndId(subIndustryId);
////        
////        List<SubIndustryDto> lisDto = new ArrayList<>();
////        for(SubIndustry s : list) {
////            SubIndustryDto dto = new SubIndustryDto();
////            dto.setSubIndustryId(s.getSubIndustryId());
////            dto.setSubIndustryName(s.getSubIndustryName());
////            //dto.setIndustryGroupId(s.getIndustryGroupId());
////            
////
////            lisDto.add(dto);
////        }
////        return lisDto; 
////    }
}